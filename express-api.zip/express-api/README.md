# Simple Express.js REST API

## Setup Instructions

```bash
npm install
node server.js
```

## API Routes

### Root

- `GET /` → Hello World

### Items

- `GET /items` → Get all items
- `GET /items/:id` → Get item by ID
- `POST /items` → Create item `{ "name": "New", "description": "..." }`
- `PUT /items/:id` → Update item
- `DELETE /items/:id` → Delete item

## Example Request (Postman)

**POST /items**
```json
{
  "name": "Test Item",
  "description": "This is a test."
}
```

**Response**
```json
{
  "id": 3,
  "name": "Test Item",
  "description": "This is a test."
}
```
