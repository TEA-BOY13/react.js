const express = require('express');
const itemsRoutes = require('./routes/items');

const app = express();
const PORT = 3000;

app.use(express.json()); // Middleware to parse JSON
app.use('/items', itemsRoutes); // Mount items router

// Root route
app.get('/', (req, res) => {
  res.send('Hello World!');
});

// 404 for invalid routes
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
