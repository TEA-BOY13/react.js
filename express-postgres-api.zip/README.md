# Express.js + PostgreSQL CRUD API

## Requirements

- Node.js
- PostgreSQL

## Setup

1. Install PostgreSQL and create a database:
   ```
   CREATE DATABASE userdb;
   ```

2. Create table:
   ```
   CREATE TABLE users (
     id SERIAL PRIMARY KEY,
     name VARCHAR(100),
     email VARCHAR(100),
     age INTEGER
   );
   ```

3. Install dependencies:
   ```
   npm install
   ```

4. Run the server:
   ```
   node server.js
   ```

5. API runs at: `http://localhost:3000/users`
